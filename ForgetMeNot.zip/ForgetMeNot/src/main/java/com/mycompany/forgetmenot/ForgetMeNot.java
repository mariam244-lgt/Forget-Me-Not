/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.forgetmenot;

/**
 *
 * @author mariam
 */
public class ForgetMeNot {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
