
package app;

import database.DatabaseManager;
import service.ReviewService;
import service.ProgressService;
import service.WrongAnswerService;
import service.SRSService;
import model.FlashCard;
import model.ProgressRecord;

public class Main {

    public static void main(String[] args) {
        
        System.out.println("ForgetMeNot Application Initialized");

        try {
            DatabaseManager dbManager = new DatabaseManager();
            dbManager.getConnection();
            
            SRSService srsService = new SRSService();
            WrongAnswerService wrongService = new WrongAnswerService();
            ProgressService progressService = new ProgressService();
            ReviewService reviewService = new ReviewService();

            int currentStreak = progressService.getStreak();
            System.out.println("Current Streak: " + currentStreak);

            reviewService.startReview();
            reviewService.submitAnswer("GOOD", "NEW");

            System.out.println("Execution Completed Successfully");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}