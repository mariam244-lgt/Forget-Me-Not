package service;

import java.time.LocalDate;

public class ReviewService {

    private final SRSservice srsService = new SRSservice();
    private final WrongAnswerService wrongService = new WrongAnswerService();
    private final ProgressService progressService = new ProgressService();

    public void submitAnswer(String rating, String currentStatus) {
        LocalDate nextDate = srsService.calculateNextReviewDate(LocalDate.now(), rating);
        String newStatus = srsService.updateCardsStatus(currentStatus, rating);

        progressService.updateDailyProgress();

        if (rating.equalsIgnoreCase("WRONG")) {
            wrongService.handleWrongAnswer();
        }

        System.out.println("Processing Rating: " + rating);
        System.out.println("New Card Status: " + newStatus);
        System.out.println("Next Review Date: " + nextDate);
    }

    public void startReview() {
        System.out.println("Review Session Started");
    }
}

