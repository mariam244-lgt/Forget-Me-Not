package service;

import model.FlashCard;
import model.WrongFlashCard;
import database.WrongCardDAO;
import java.util.List;

public class WrongAnswerService {
    
    private final WrongCardDAO wrongCardDAO;

    public WrongAnswerService() {
        this.wrongCardDAO = new WrongCardDAO();
    }

    public void handleWrongAnswer() {
        System.out.println("الربط اشتغل: تم استلام إشارة الخطأ وجاري المعالجة...");
    }

    public void addWrongCard(FlashCard card) {
        System.out.println("Adding card to wrong answers: " + card.getQuestion());
    }

    public List<WrongFlashCard> getWrongCardsByDeck(String deckName) {
        return wrongCardDAO.getWrongCardsByDeck(deckName);
    }

    public void deleteWrongCard(int id) {
        wrongCardDAO.deleteWrongCard(id);
        System.out.println("Deleted wrong card with ID: " + id);
    }
}
