package service;

import database.ProgressDAO;
import model.ProgressRecord;
import java.time.LocalDate;
import java.util.List;

public class ProgressService {

    private final ProgressDAO progressDAO;

    public ProgressService() {
        this.progressDAO = new ProgressDAO();
    }

    public void updateDailyProgress() {
        int currentCards = getTodayCards();
        markDayCompleted(currentCards + 1);
        System.out.println("Daily progress updated. Total cards today: " + (currentCards + 1));
    }

    public void markDayCompleted(int cards) {
        ProgressRecord today = progressDAO.getByDate(LocalDate.now());

        if (today == null) {
            today = new ProgressRecord(LocalDate.now(), true, cards);
            progressDAO.insert(today);
        } else {
            today.setCompleted(true);
            today.setCardsReviewed(cards);
            progressDAO.update(today);
        }
    }

    public int getStreak() {
        int streak = 0;
        LocalDate date = LocalDate.now();
        while (true) {
            ProgressRecord record = progressDAO.getByDate(date);
            if (record != null && record.isCompleted()) {
                streak++;
                date = date.minusDays(1);
            } else {
                break;
            }
        }
        return streak;
    }

    public List<ProgressRecord> getProgressForYear(int year) {
        return progressDAO.getByYear(year);
    }

    public int getTodayCards() {
        ProgressRecord today = progressDAO.getByDate(LocalDate.now());
        return today != null ? today.getCardsReviewed() : 0;
    }

    public boolean isTodayCompleted() {
        ProgressRecord today = progressDAO.getByDate(LocalDate.now());
        return today != null && today.isCompleted();
    }
}
    

