
package service;

import java.time.LocalDate;
public class SRSservice {
 private final double easyFactor=2.5;
 public LocalDate calculateNextReviewDate(LocalDate now, String rating){
LocalDate today =LocalDate.now() ;

int daysToAdd = 0;
if(rating.equalsIgnoreCase("easy")){
daysToAdd = (int)(3*easyFactor);
}else if(rating.equalsIgnoreCase("hard")){
daysToAdd = 1;
}else{
    daysToAdd = 0;
}
return today.plusDays(daysToAdd);
 }

    String updateCardsStatus(String currentStatus, String rating) {
    }
}




 
 
 
 
 
        
        
        
        
   
 
}
